package org.sid.atelier6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atelier6ApplicationTests {

    @Test
    void contextLoads() {
    }

}
