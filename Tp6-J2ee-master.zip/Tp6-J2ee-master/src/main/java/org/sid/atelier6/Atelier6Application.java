package org.sid.atelier6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atelier6Application {

    public static void main(String[] args) {
        SpringApplication.run(Atelier6Application.class, args);
    }

}
